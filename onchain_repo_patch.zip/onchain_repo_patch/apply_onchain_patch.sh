#!/usr/bin/env bash
set -euo pipefail
# Apply on-chain policy gate into your solidity repo
# Usage: ./apply_onchain_patch.sh /path/to/onchain/repo
REPO_DIR="${1:-}"
if [ -z "$REPO_DIR" ]; then
  echo "Usage: $0 /path/to/repo" >&2
  exit 1
fi
cd "$REPO_DIR"
rsync -a "/mnt/data/pr_branches_8785_to_3461/onchain_repo_patch/contracts/" "./contracts/"
rsync -a "/mnt/data/pr_branches_8785_to_3461/onchain_repo_patch/test/" "./test/"
rsync -a "/mnt/data/pr_branches_8785_to_3461/onchain_repo_patch/.github/" "./.github/"
cp "/mnt/data/pr_branches_8785_to_3461/onchain_repo_patch/package.json" "./package.json"
cp "/mnt/data/pr_branches_8785_to_3461/onchain_repo_patch/hardhat.config.ts" "./hardhat.config.ts"
cp "/mnt/data/pr_branches_8785_to_3461/onchain_repo_patch/tsconfig.json" "./tsconfig.json"
cp "/mnt/data/pr_branches_8785_to_3461/onchain_repo_patch/README.md" "./README_code_gate.md"
cp "/mnt/data/pr_branches_8785_to_3461/onchain_repo_patch/CODEOWNERS" "./CODEOWNERS"
echo "On-chain patch applied. Run: npm i && npm run build && npm test"
