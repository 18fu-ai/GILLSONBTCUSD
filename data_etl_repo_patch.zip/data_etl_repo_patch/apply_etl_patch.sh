#!/usr/bin/env bash
set -euo pipefail
# Apply ETL migration tool and redirect map to your data repo
# Usage: ./apply_etl_patch.sh /path/to/data/repo
REPO_DIR="${1:-}"
if [ -z "$REPO_DIR" ]; then
  echo "Usage: $0 /path/to/repo" >&2
  exit 1
fi
cd "$REPO_DIR"
mkdir -p tools/migrations
cp "/mnt/data/pr_branches_8785_to_3461/data_etl_repo_patch/etl_apply_migration.py" "./tools/migrations/etl_apply_migration.py"
if [ -f "/mnt/data/pr_branches_8785_to_3461/data_etl_repo_patch/migration_redirects.csv" ]; then
  cp "/mnt/data/pr_branches_8785_to_3461/data_etl_repo_patch/migration_redirects.csv" "./tools/migrations/migration_redirects.csv"
fi
echo "ETL patch applied. Example: cat legacy.ndjson | python3 tools/migrations/etl_apply_migration.py --ndjson > fixed.ndjson"
