# NS Verification Kit v2 — FFT Projection + CuPy Option + Signing

This version folds in a **spectral (FFT) Poisson projection** for 3D (periodic),
keeps the **2D stable ETDRK4** solver, and adds **Ed25519 signing** utilities.
If **CuPy** is available, the 3D FFT path auto-runs on GPU (AMD ROCm/NVIDIA).

## Files
- `ns2d_spectral_stable.py` — 2D pseudo-spectral ETDRK4 with rigorous dealias.
- `ns3d_projection_guarded_fft_xp.py` — 3D FFT projection (NumPy/CuPy) with CFL + diffusion caps & velocity clamp.
- `invariants_check.py` — helper diagnostics.
- `sign_results.py` / `verify_signature.py` — Ed25519 sign/verify artifacts.

## Quick 3D run (CPU or GPU via CuPy)
```python
from ns3d_projection_guarded_fft_xp import simulate
u,v,w,t,div,E = simulate(n=24, nu=1e-2, dt=5e-4, steps=60, seed=444)
```

## Signing an artifact
```bash
export ATTESTATION_PRIVATE_KEY_PEM="$(cat /path/to/ed25519_private_key.pem)"
python sign_results.py UE_Superiority_Audit_NS_Run_v4.json
python verify_signature.py UE_Superiority_Audit_NS_Run_v4.json UE_Superiority_Audit_NS_Run_v4.json.sig.json
```

## Notes
- FFT projection assumes **periodic** boundaries.
- For Unreal demos, use small grids (n=24–48) with ν≥1e-2 and CFL≤0.35 for robust visuals.
- Merge the `.sig.json` into your ValorAiEngine+ Attestation records (signature, publicKeyPem, digestHex).
