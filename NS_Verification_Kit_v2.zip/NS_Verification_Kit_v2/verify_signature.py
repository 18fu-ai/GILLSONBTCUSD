#!/usr/bin/env python3
"""
verify_signature.py
Verifies a .sig.json against the original file using Ed25519.
"""
import sys, json, base64, hashlib
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.hazmat.primitives import serialization

def main():
    if len(sys.argv) != 3:
        print("Usage: verify_signature.py <file.json> <file.json.sig.json>")
        sys.exit(1)
    f = Path(sys.argv[1]); s = Path(sys.argv[2])
    sig = json.loads(s.read_text(encoding="utf-8"))
    data = f.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if digest != sig.get("digestHex"):
        print("Digest mismatch"); sys.exit(2)
    pub = serialization.load_pem_public_key(sig["publicKeyPem"].encode("utf-8"))
    if not isinstance(pub, Ed25519PublicKey):
        print("Not an Ed25519 public key"); sys.exit(2)
    pub.verify(base64.b64decode(sig["signature"]), data)
    print("OK: signature verified")
    sys.exit(0)

if __name__ == "__main__":
    main()
