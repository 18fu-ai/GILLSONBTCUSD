
#!/usr/bin/env python3
# ns3d_projection_guarded_fft_xp.py
# 3D incompressible NS (periodic) with FFT-based projection.
# Uses NumPy by default; auto-switches to CuPy if available (GPU/ROCm).
try:
    import cupy as xp  # CuPy (AMD ROCm/NVIDIA CUDA)
    _GPU = True
except Exception:
    import numpy as xp  # NumPy fallback
    _GPU = False

def to_cpu(a):
    import numpy as np
    return xp.asnumpy(a) if _GPU else a

def make_wave_numbers(n, L=1.0):
    k = 2*xp.pi*xp.fft.fftfreq(n, d=L/n)
    kx, ky, kz = xp.meshgrid(k, k, k, indexing='ij')
    k2 = kx*kx + ky*ky + kz*kz
    k2[(0,0,0)] = 1.0
    return kx, ky, kz, k2

def laplacian(u, dx):
    return (xp.roll(u,-1,0)+xp.roll(u,1,0)+xp.roll(u,-1,1)+xp.roll(u,1,1)+xp.roll(u,-1,2)+xp.roll(u,1,2)-6*u)/(dx*dx)

def divergence(u, v, w, dx):
    dudx = (xp.roll(u,-1,0) - xp.roll(u,1,0)) / (2*dx)
    dvdy = (xp.roll(v,-1,1) - xp.roll(v,1,1)) / (2*dx)
    dwdz = (xp.roll(w,-1,2) - xp.roll(w,1,2)) / (2*dx)
    return dudx + dvdy + dwdz

def advect_upwind_guarded(q, u, v, w, dx, vmax=5.0):
    u = xp.clip(u, -vmax, vmax); v = xp.clip(v, -vmax, vmax); w = xp.clip(w, -vmax, vmax)
    qx_f = xp.where(u>0, q - xp.roll(q,1,0), xp.roll(q,-1,0) - q) / dx
    qy_f = xp.where(v>0, q - xp.roll(q,1,1), xp.roll(q,-1,1) - q) / dx
    qz_f = xp.where(w>0, q - xp.roll(q,1,2), xp.roll(q,-1,2) - q) / dx
    return -(u*qx_f + v*qy_f + w*qz_f)

def pressure_fft(div_star_dt, k2):
    rhs_hat = xp.fft.fftn(div_star_dt)
    p_hat = - rhs_hat / k2
    p_hat[(0,0,0)] = 0.0
    p = xp.fft.ifftn(p_hat).real
    return p

def step(u, v, w, nu, dt, dx, kx, ky, kz, k2, cfl=0.3, vmax=5.0):
    max_vel = float(to_cpu(xp.max(xp.sqrt((u*u + v*v + w*w))))) + 1e-12
    dt_cfl  = cfl * dx / max_vel
    dt_diff = 0.35 * dx*dx / max(nu, 1e-12)
    dt = min(dt, dt_cfl, dt_diff)

    Au = nu*laplacian(u, dx); Av = nu*laplacian(v, dx); Aw = nu*laplacian(w, dx)
    Nu = advect_upwind_guarded(u,u,v,w,dx,vmax=vmax)
    Nv = advect_upwind_guarded(v,u,v,w,dx,vmax=vmax)
    Nw = advect_upwind_guarded(w,u,v,w,dx,vmax=vmax)

    u_star = u + dt*(Au + Nu); v_star = v + dt*(Av + Nv); w_star = w + dt*(Aw + Nw)

    div_star = divergence(u_star, v_star, w_star, dx)
    p = pressure_fft(div_star/dt, k2)

    px = xp.fft.ifftn(1j*kx*xp.fft.fftn(p)).real
    py = xp.fft.ifftn(1j*ky*xp.fft.fftn(p)).real
    pz = xp.fft.ifftn(1j*kz*xp.fft.fftn(p)).real

    u_next = u_star - dt*px
    v_next = v_star - dt*py
    w_next = w_star - dt*pz
    if _GPU:
        import cupy as cp; u_next = cp.nan_to_num(u_next); v_next = cp.nan_to_num(v_next); w_next = cp.nan_to_num(w_next)
    else:
        import numpy as np; u_next = np.nan_to_num(u_next); v_next = np.nan_to_num(v_next); w_next = np.nan_to_num(w_next)
    return u_next, v_next, w_next, p, dt

def simulate(n=24, L=1.0, nu=1e-2, dt=5e-4, steps=60, seed=0):
    import numpy as np
    dx = L/n
    kx, ky, kz, k2 = make_wave_numbers(n, L)
    rng = np.random.default_rng(seed)
    u = xp.array(rng.normal(scale=0.03, size=(n,n,n)), dtype=xp.float64)
    v = xp.array(rng.normal(scale=0.03, size=(n,n,n)), dtype=xp.float64)
    w = xp.array(rng.normal(scale=0.03, size=(n,n,n)), dtype=xp.float64)

    t=0.0; times=[0.0]; divs=[]; Es=[]
    def energy(u,v,w): 
        e = 0.5*xp.mean(u*u + v*v + w*w)
        return float(to_cpu(e))

    divs.append(float(to_cpu(xp.abs(divergence(u,v,w,dx)).mean()))); Es.append(energy(u,v,w))
    for s in range(steps):
        u, v, w, p, dt_eff = step(u, v, w, nu, dt, dx, kx, ky, kz, k2, cfl=0.3, vmax=5.0)
        t += dt_eff
        if (s+1) % max(1, steps//10) == 0:
            times.append(t)
            divs.append(float(to_cpu(xp.abs(divergence(u,v,w,dx)).mean())))
            Es.append(energy(u,v,w))
            print(f"[fft-xp {s+1}/{steps}] t={t:.4f} mean|div|={divs[-1]:.3e} E={Es[-1]:.6f} GPU={_GPU}")
    return to_cpu(u), to_cpu(v), to_cpu(w), np.array(times), np.array(divs), np.array(Es)
