
#!/usr/bin/env python3
# ns2d_spectral_stable.py — 2D incompressible Navier–Stokes (periodic) via pseudo‑spectral ETDRK4
# Kassam–Trefethen contour quadrature for ETDRK4 (M=16) + rigorous dealiasing and mask on final state.
import numpy as np

def dealias_mask(n):
    k = np.fft.fftfreq(n) * n
    cutoff = (2.0/3.0) * (n/2.0)
    mask_1d = (np.abs(k) <= cutoff).astype(float)
    return np.outer(mask_1d, mask_1d)

def make_wavenumbers(n, L=2*np.pi):
    k = np.fft.fftfreq(n, d=L/n) * 2*np.pi
    kx, ky = np.meshgrid(k, k, indexing='ij')
    k2 = kx*kx + ky*ky
    k2[0,0] = 1.0
    return kx, ky, k2

def jacobian(psi, w, kx, ky, mask):
    psi_x = np.fft.ifft2(1j*kx * np.fft.fft2(psi)).real
    psi_y = np.fft.ifft2(1j*ky * np.fft.fft2(psi)).real
    w_x   = np.fft.ifft2(1j*kx * np.fft.fft2(w)).real
    w_y   = np.fft.ifft2(1j*ky * np.fft.fft2(w)).real
    J = psi_x * w_y - psi_y * w_x
    return np.fft.ifft2(np.fft.fft2(J) * mask).real

def energy_enstrophy(w, kx, ky, k2):
    psi_hat = -np.fft.fft2(w) / k2
    psi_hat[0,0] = 0.0
    psi_x = np.fft.ifft2(1j*kx * psi_hat).real
    psi_y = np.fft.ifft2(1j*ky * psi_hat).real
    u = np.stack((-psi_y, psi_x), axis=0)
    E = 0.5 * np.mean(u[0]**2 + u[1]**2)
    Z = 0.5 * np.mean(w**2)
    return E, Z

def etdrk4_coeffs(Lh, dt, M=16):
    # Kassam–Trefethen contour quadrature for phi functions
    Ldt = Lh*dt
    E  = np.exp(Ldt)
    E2 = np.exp(Ldt/2)
    r = np.exp(1j*np.pi*(np.arange(1, M+1)-0.5)/M)  # points on unit circle in right half-plane
    LR = Ldt[..., None] + r  # broadcast over grid
    Q  = dt * np.mean((np.exp(LR/2) - 1.0) / LR, axis=-1)
    f1 = dt * np.mean((-4 - LR + np.exp(LR)*(4 - 3*LR + LR**2)) / (LR**3), axis=-1)
    f2 = dt * np.mean((2 + LR + np.exp(LR)*(-2 + LR)) / (LR**3), axis=-1)
    f3 = dt * np.mean((-4 - 3*LR - LR**2 + np.exp(LR)*(4 - LR)) / (LR**3), axis=-1)
    return E, E2, Q, f1, f2, f3

def step_etdrk4(w, nu, dt, kx, ky, k2, mask):
    Lh = -nu * k2
    E, E2, Q, f1, f2, f3 = etdrk4_coeffs(Lh, dt, M=16)
    def N(w):
        psi_hat = -np.fft.fft2(w) / k2
        psi_hat[0,0] = 0.0
        psi = np.fft.ifft2(psi_hat).real
        J = jacobian(psi, w, kx, ky, mask)
        return -J

    w_hat = np.fft.fft2(w) * mask
    Nv = np.fft.fft2(N(w)) * mask
    a_hat = E2 * w_hat + Q * Nv
    Na = np.fft.fft2(N(np.fft.ifft2(a_hat).real)) * mask
    b_hat = E2 * w_hat + Q * Na
    Nb = np.fft.fft2(N(np.fft.ifft2(b_hat).real)) * mask
    c_hat = E2 * a_hat + Q * (2*Nb - Nv)
    Nc = np.fft.fft2(N(np.fft.ifft2(c_hat).real)) * mask

    w_hat_next = E * w_hat + f1*Nv + 2*f2*(Na + Nb) + f3*Nc
    w_hat_next *= mask  # enforce dealias at end
    return np.fft.ifft2(w_hat_next).real

def simulate(n=128, L=2*np.pi, nu=2e-3, dt=2e-4, steps=1000, seed=0):
    rng = np.random.default_rng(seed)
    kx, ky, k2 = make_wavenumbers(n, L)
    mask = dealias_mask(n)
    # random smooth initial vorticity via streamfunction spectrum
    psi0_hat = (rng.normal(size=(n,n)) + 1j*rng.normal(size=(n,n))) * np.exp(-0.5*(k2/(0.25*(n/L))**2))
    w0_hat = (-k2) * psi0_hat * mask
    w = np.fft.ifft2(w0_hat).real
    E0, Z0 = energy_enstrophy(w, kx, ky, k2)
    for s in range(steps):
        w = step_etdrk4(w, nu, dt, kx, ky, k2, mask)
        if (s+1) % max(1, steps//10) == 0:
            E, Z = energy_enstrophy(w, kx, ky, k2)
            print(f"[{s+1}/{steps}] E={E:.6e} Z={Z:.6e}")
    return w
