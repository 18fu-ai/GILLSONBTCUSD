#!/usr/bin/env python3
"""
sign_results.py
Signs a file with Ed25519 using a PEM private key (env or file).
Outputs a .sig.json containing: digestHex, signature (base64), publicKeyPem.
"""
import os, sys, json, base64, hashlib
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization

def load_private_key(pem_str: str):
    key = serialization.load_pem_private_key(pem_str.encode("utf-8"), password=None)
    if not isinstance(key, Ed25519PrivateKey):
        raise ValueError("Expected an Ed25519 private key PEM")
    return key

def main():
    if len(sys.argv) < 2:
        print("Usage: sign_results.py <file.json> [pem_path]")
        sys.exit(1)
    target = Path(sys.argv[1])
    pem = None
    if len(sys.argv) >= 3:
        pem = Path(sys.argv[2]).read_text(encoding="utf-8")
    else:
        pem = os.environ.get("ATTESTATION_PRIVATE_KEY_PEM")
        if not pem:
            print("Set ATTESTATION_PRIVATE_KEY_PEM or pass pem_path")
            sys.exit(2)

    key = load_private_key(pem)
    pub = key.public_key().public_bytes(encoding=serialization.Encoding.PEM, format=serialization.PublicFormat.SubjectPublicKeyInfo).decode("utf-8")
    data = target.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    sig = key.sign(data)
    out = {
        "file": target.name,
        "digestHex": digest,
        "signature": base64.b64encode(sig).decode("ascii"),
        "publicKeyPem": pub
    }
    out_path = target.with_suffix(target.suffix + ".sig.json")
    out_path.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print("Wrote", out_path)

if __name__ == "__main__":
    main()
