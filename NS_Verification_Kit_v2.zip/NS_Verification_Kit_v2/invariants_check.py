
#!/usr/bin/env python3
# invariants_check.py — Helpers to check divergence, energy, and discrete dissipation.

import numpy as np

def divergence(u, v, w, dx):
    dudx = (np.roll(u,-1,0) - np.roll(u,1,0)) / (2*dx)
    dvdy = (np.roll(v,-1,1) - np.roll(v,1,1)) / (2*dx)
    dwdz = (np.roll(w,-1,2) - np.roll(w,1,2)) / (2*dx)
    return dudx + dvdy + dwdz

def kinetic_energy(u, v, w):
    return 0.5*np.mean(u*u + v*v + w*w)

def enstrophy_2d(w):
    return 0.5*np.mean(w*w)
