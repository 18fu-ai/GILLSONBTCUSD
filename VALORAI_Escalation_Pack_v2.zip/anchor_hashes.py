#!/usr/bin/env python3
import hashlib, json, pathlib, time
UTC="2025-09-01T01:14:35Z"
targets = []
for p in pathlib.Path('.').glob('*.pdf'):
    with open(p, 'rb') as f: h = hashlib.sha256(f.read()).hexdigest()
    targets.append({"file": p.name, "sha256": h, "op_return_cmd":
        "bitcoin-cli -named walletcreatefundedpsbt inputs='[]' outputs='[{\\\"data\\\":\\\""+h+"\\\"}]' includeWatching=true"})
print(json.dumps({"timestamp_utc":UTC,"targets":targets}, indent=2))
