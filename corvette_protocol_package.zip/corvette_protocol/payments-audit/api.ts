import { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';

// Initialize a single PrismaClient instance. In a real-world application,
// you would ensure this is reused across requests to avoid exhausting
// database connections. See the Prisma documentation for details.
const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  try {
    const page = parseInt((req.query.page as string) || '1');
    const limit = parseInt((req.query.limit as string) || '10');

    // Use a transaction to fetch both the paginated payments and the total count
    const [payments, total] = await prisma.$transaction([
      prisma.payment.findMany({
        skip: (page - 1) * limit,
        take: limit,
        orderBy: { createdAt: 'desc' }
      }),
      prisma.payment.count()
    ]);

    res.status(200).json({ payments, total });
  } catch (error) {
    console.error('Error fetching payments:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}