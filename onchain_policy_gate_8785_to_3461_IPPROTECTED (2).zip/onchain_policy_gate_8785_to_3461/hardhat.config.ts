import { HardhatUserConfig } from "hardhat/config";
import "@nomicfoundation/hardhat-toolbox";

const config: HardhatUserConfig = {
  solidity: "0.8.20",
};
export default config;

// © 2025 That's Edutainment, LLC — ValorAi+® | ValorAiMathAVM™ | ValorPhysics+™
// All rights reserved. Trademarks: VALORAIPLUS® and associated marks.
// Use subject to license and access controls. Unauthorized use prohibited.
// Proof: urn:valor:migration:8785-to-3461
// SHA256: 771b172945d1e106f3007c4b65fd30abcbaa16bea2d3c3cc8a55300e9c3237ab
// SHA3-256: 560b84594a7972f0b371390846970cee2d529e932ad980ed31bd80ff75ec27dd
// BLAKE2b-512: 3df95aa6a4b575adbbd52ecdee50cd96e8d22fbf5de7c7285f00e7a03500c4f01b3fa8ce34fd18683c588bc171a32618d7cca9606e816253929eac5a3040bea3
