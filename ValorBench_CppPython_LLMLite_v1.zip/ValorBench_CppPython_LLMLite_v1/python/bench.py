#!/usr/bin/env python3
import json, time, platform
import numpy as np
from statistics import median

def tsec(fn, repeats=3, warmup=1):
    for _ in range(warmup): fn()
    times = []
    for _ in range(repeats):
        t0 = time.perf_counter(); fn(); t1 = time.perf_counter()
        times.append(t1-t0)
    return min(times), median(times)

def bench_numpy():
    results = []

    # Matmul
    n=256
    A = np.random.default_rng(0).standard_normal((n,n), dtype=np.float32)
    B = np.random.default_rng(1).standard_normal((n,n), dtype=np.float32)
    def run_mm(): (A@B)  # numpy dispatches to BLAS if present
    best, med = tsec(run_mm, repeats=3)
    results.append({"name":"matmul_numpy","params":f"n={n}","sec_best":best,"sec_med":med})

    # Attention
    seq=128; d=64; scale=1/np.sqrt(d)
    Q = np.random.default_rng(2).standard_normal((seq,d), dtype=np.float32)
    K = np.random.default_rng(3).standard_normal((seq,d), dtype=np.float32)
    V = np.random.default_rng(4).standard_normal((seq,d), dtype=np.float32)
    def run_attn():
        S = (Q @ K.T) * scale
        S = S - S.max(axis=1, keepdims=True)
        S = np.exp(S, dtype=np.float32); S /= S.sum(axis=1, keepdims=True)
        O = S @ V
        return O
    best, med = tsec(run_attn, repeats=3)
    results.append({"name":"attention_numpy","params":f"seq={seq},d={d}","sec_best":best,"sec_med":med,
                    "tokens_per_s_est": float(seq*seq/med)})

    # 3D stencil
    n=64; steps=5
    rng = np.random.default_rng(5)
    u = rng.standard_normal((n,n,n), dtype=np.float32)
    v = rng.standard_normal((n,n,n), dtype=np.float32)
    w = rng.standard_normal((n,n,n), dtype=np.float32)
    q = rng.standard_normal((n,n,n), dtype=np.float32)
    def run_stencil():
        nonlocal u,v,w,q
        for _ in range(steps):
            qx = (np.roll(q,-1,0) - np.roll(q,1,0))*0.5
            qy = (np.roll(q,-1,1) - np.roll(q,1,1))*0.5
            qz = (np.roll(q,-1,2) - np.roll(q,1,2))*0.5
            q = q - 0.1*(u*qx + v*qy + w*qz)
        return q
    best, med = tsec(run_stencil, repeats=3)
    results.append({"name":"stencil3d_numpy","params":f"n={n},steps={steps}","sec_best":best,"sec_med":med})

    meta = {
        "language":"Python",
        "python_version": platform.python_version(),
        "numpy_version": np.__version__,
        "blas_info": np.__config__.show(),  # prints to stdout; placeholder
    }
    return {"meta": meta, "results": results}

if __name__ == "__main__":
    out = bench_numpy()
    print(json.dumps(out, indent=2))
