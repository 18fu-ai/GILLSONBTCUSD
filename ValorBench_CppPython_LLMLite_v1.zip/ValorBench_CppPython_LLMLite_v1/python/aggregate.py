#!/usr/bin/env python3
import json, sys, pathlib

def load(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def main():
    if len(sys.argv) < 3:
        print("Usage: aggregate.py cpp.json python.json")
        sys.exit(1)
    cpp = load(sys.argv[1]); py = load(sys.argv[2])
    # Map results by name
    cpp_map = {r["name"]: r for r in cpp.get("results", [])}
    py_map  = {r["name"].replace("_numpy","").replace("_eigen","").replace("_naive",""): r for r in py.get("results", [])}

    merged = []
    for key, p in py_map.items():
        c = cpp_map.get(key+"_naive") or cpp_map.get(key+"_eigen") or cpp_map.get(key)
        entry = {"bench": key, "python_sec_med": p.get("sec_med"), "python_params": p.get("params")}
        if c:
            entry["cpp_sec"] = c.get("sec")
            entry["cpp_params"] = c.get("params")
            entry["speedup_cpp_over_py"] = p.get("sec_med")/c.get("sec")
        merged.append(entry)

    print(json.dumps({"merged": merged}, indent=2))

if __name__ == "__main__":
    main()
