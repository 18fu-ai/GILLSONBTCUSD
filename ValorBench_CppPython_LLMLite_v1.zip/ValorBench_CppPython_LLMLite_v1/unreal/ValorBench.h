#pragma once
#include "CoreMinimal.h"
class FValorBench
{
public:
  static void Run();
};
