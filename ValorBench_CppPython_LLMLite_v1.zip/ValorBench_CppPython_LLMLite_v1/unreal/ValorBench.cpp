#include "ValorBench.h"
#include "Misc/OutputDeviceDebug.h"
#include <chrono>
#include <vector>
#include <random>
static float frand(){ static std::mt19937 rng(42); static std::uniform_real_distribution<float> d(-1.f,1.f); return d(rng); }

void FValorBench::Run(){
  using clk = std::chrono::high_resolution_clock;
  auto benchMatmul = [](){
    const int n=128;
    std::vector<float> A(n*n), B(n*n), C(n*n, 0.f);
    for(auto& x:A)x=frand(); for(auto& x:B)x=frand();
    auto t0 = clk::now();
    for(int i=0;i<n;i++){ for(int k=0;k<n;k++){ float aik=A[i*n+k]; for(int j=0;j<n;j++){ C[i*n+j]+=aik*B[k*n+j]; } } }
    auto t1 = clk::now();
    double sec = std::chrono::duration<double>(t1-t0).count();
    UE_LOG(LogTemp, Display, TEXT("[ValorBench] matmul_naive n=128 : %f sec"), sec);
  };
  benchMatmul();
}
