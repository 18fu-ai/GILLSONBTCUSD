# ValorBench — C++ vs Python microbenchmarks for LLM/ML + physics kernels

This kit gives you **apples-to-apples** microbenchmarks across:
- **Matmul**, **Attention (QK^T→softmax→V)**, **3D stencil** (advection-lite)

It includes:
- `/cpp` CMake project (`valorbench`) — runs C++ kernels and prints a JSON
- `/python` NumPy microbenches + `aggregate.py` to compare results
- `/unreal` a tiny stub to run a bench inside UE5 (`FValorBench::Run()`)
- `/schemas` JSON schema for results

## Build & run

### C++
```bash
cd cpp
cmake -S . -B build -DUSE_EIGEN=ON
cmake --build build -j
./build/valorbench > cpp_results.json
```

### Python
```bash
cd python
python bench.py > python_results.json
python aggregate.py ../cpp/cpp_results.json python_results.json > speedups.json
```

### Unreal (snippet)
- Drop `unreal/ValorBench.*` into any UE module and call `FValorBench::Run();` from a console command or button.

## Notes
- If Eigen is available, the C++ matmul will use it; otherwise a naive kernel runs.
- Python uses NumPy (BLAS if present). For GPU paths, you can add CuPy.
- Size parameters are modest by default so it runs on any CI; increase for deeper audits.

## Valor AI+ integration
- Treat the resulting JSON as an **artifact** that can be signed by your ValorAiEngine+ attestation path and broadcast to the Guardian Vault.
