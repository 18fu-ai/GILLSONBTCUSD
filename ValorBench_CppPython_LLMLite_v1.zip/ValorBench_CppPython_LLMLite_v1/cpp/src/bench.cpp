#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <random>
#include <iostream>

#ifdef HAVE_EIGEN3
  #include <Eigen/Dense>
#endif

using clk = std::chrono::high_resolution_clock;
double secs(std::chrono::duration<double> d){return d.count();}

struct Result {
  std::string name;
  std::string params;
  double sec;
};

std::mt19937 rng(42);
float frand(){ static std::uniform_real_distribution<float> dist(-1.f,1.f); return dist(rng); }

// naive matmul (row-major)
void matmul_naive(const float* A, const float* B, float* C, int n){
  for(int i=0;i<n;i++){
    for(int k=0;k<n;k++){
      float aik = A[i*n+k];
      for(int j=0;j<n;j++) C[i*n+j] += aik * B[k*n+j];
    }
  }
}

// attention microkernel: QK^T -> softmax -> x V
void attention_naive(const float* Q, const float* K, const float* V, float* O, int seq, int d){
  // compute scores = Q K^T / sqrt(d)
  std::vector<float> S(seq*seq, 0.f);
  float scale = 1.f/std::sqrt((float)d);
  for(int i=0;i<seq;i++){
    for(int j=0;j<seq;j++){
      float s=0.f;
      for(int k=0;k<d;k++) s += Q[i*d+k]*K[j*d+k];
      S[i*seq+j] = s*scale;
    }
  }
  // softmax rows
  for(int i=0;i<seq;i++){
    float mx = -1e30f;
    for(int j=0;j<seq;j++) mx = std::max(mx, S[i*seq+j]);
    float sum=0.f;
    for(int j=0;j<seq;j++){ S[i*seq+j] = std::exp(S[i*seq+j]-mx); sum += S[i*seq+j]; }
    for(int j=0;j<seq;j++){ S[i*seq+j] /= sum; }
  }
  // O = S V
  for(int i=0;i<seq;i++){
    for(int k=0;k<d;k++){
      float s=0.f;
      for(int j=0;j<seq;j++) s += S[i*seq+j]*V[j*d+k];
      O[i*d+k] = s;
    }
  }
}

int main(){
  std::vector<Result> results;

  auto bench = [&](const std::string& name, const std::string& params, auto fn){
    auto t0 = clk::now();
    fn();
    auto t1 = clk::now();
    results.push_back({name, params, secs(t1-t0)});
  };

  // Matmul n=512
  {
    int n=256; // keep compile/run light; change to 512/1024 for full power
    std::vector<float> A(n*n), B(n*n), C(n*n, 0.f);
    for(auto& x : A) x = frand();
    for(auto& x : B) x = frand();
#ifdef HAVE_EIGEN3
    bench("matmul_eigen", "n=256", [&](){
      Eigen::Map<Eigen::MatrixXf> Am(A.data(), n, n);
      Eigen::Map<Eigen::MatrixXf> Bm(B.data(), n, n);
      Eigen::Map<Eigen::MatrixXf> Cm(C.data(), n, n);
      Cm.noalias() = Am*Bm;
    });
#else
    bench("matmul_naive", "n=256", [&](){ matmul_naive(A.data(), B.data(), C.data(), n); });
#endif
  }

  // Attention: seq=256, d=64
  {
    int seq=128, d=64;
    std::vector<float> Q(seq*d), K(seq*d), V(seq*d), O(seq*d);
    for(auto& x : Q) x = frand();
    for(auto& x : K) x = frand();
    for(auto& x : V) x = frand();
    bench("attention_naive", "seq=128,d=64", [&](){ attention_naive(Q.data(),K.data(),V.data(),O.data(),seq,d); });
  }

  // 3D stencil (advection-lite): n=64, 5 steps
  {
    int n=64; int steps=5;
    size_t N = (size_t)n*n*n;
    std::vector<float> u(N), v(N), w(N), q(N), qn(N);
    for(size_t i=0;i<N;i++){u[i]=frand();v[i]=frand();w[i]=frand();q[i]=frand();}
    auto idx=[&](int x,int y,int z){ x=(x+n)%n; y=(y+n)%n; z=(z+n)%n; return (size_t)(x*n*n + y*n + z); };
    bench("stencil3d", "n=64,steps=5", [&](){
      for(int s=0;s<steps;s++){
        for(int x=0;x<n;x++)for(int y=0;y<n;y++)for(int z=0;z<n;z++){
          size_t i = idx(x,y,z);
          float qx = (q[idx(x+1,y,z)]-q[idx(x-1,y,z)])*0.5f;
          float qy = (q[idx(x,y+1,z)]-q[idx(x,y-1,z)])*0.5f;
          float qz = (q[idx(x,y,z+1)]-q[idx(x,y,z-1)])*0.5f;
          qn[i] = q[i] - 0.1f*(u[i]*qx + v[i]*qy + w[i]*qz);
        }
        q.swap(qn);
      }
    });
  }

  // Dump JSON
  std::cout << "{\n  \"language\": \"C++\",\n  \"results\": [\n";
  for(size_t i=0;i<results.size();++i){
    const auto& r = results[i];
    std::cout << "    {\"name\":\"" << r.name << "\",\"params\":\"" << r.params << "\",\"sec\":" << r.sec << "}";
    if(i+1<results.size()) std::cout << ",";
    std::cout << "\n";
  }
  std::cout << "  ]\n}\n";
  return 0;
}
