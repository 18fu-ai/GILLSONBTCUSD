# ValorAi+ — System Architecture Deep Dive (v1)

> Directive-anchored architecture referencing the 8785→3461 migration, strict JCS proofs, on-chain policy, and agent-driven governance.

## 1) Executive Overview
ValorAi+ is a provenance-first platform for **Payments (ValorAiPlusPay)** and **LegalShield+** workflows, unified by machine-verifiable **semantic metadata** and **tamper-proof proofs**. Core pillars:

- **Semantic Metadata** (RDF/OWL + JSON-LD + SHACL)
- **Proofs**: JCS (RFC 8785) canonicalization + multi-hash + detached signatures (JWS/COSE)
- **C2PA wiring** for trusted-media provenance
- **On-chain**: Licensing, royalties (ERC-2981), and policy enforcement
- **Services**: REST microservices for ingest → validate → stamp → store → sign
- **Agentic Ops**: GitHub-driven CI/PR automation to enact policy (8785→3461), block regressions, and roll out changes across repos

## 2) Logical Architecture
```mermaid
graph TD
  A[Client / Producer] -->|Submit asset + metadata| B[Metadata Service API]
  B -->|normalize & enforce| B1[Code Policy: 8785→3461, 7226 preserved]
  B -->|JCS canonicalize| C[Proof Engine]
  C -->|hashes + HMAC/JWS| D[Stamped Manifest]
  D -->|C2PA attach| E[Media/Claims Pipeline]
  D -->|on-chain refs| F[ValorLicense.sol / Royalty]
  F -->|policy-check| G[DAO Policy Oracle]
  B -->|store| H[Manifest Storage]
  I[Agent Manager] -->|patch & PRs| J[Repos: service/on-chain/data]
  J -->|CI| K[Checks: hash verify & 8785 gate]
```

## 3) Data & Control Flows
1. **Ingest** → `/validate` normalizes **8785 → 3461**; rejects residual 8785.
2. **Stamp** → JSON-LD copied (minus `proof`) → **JCS** → hashes (sha256/sha3-256/blake2b-512) → `proof` section.
3. **Sign** (optional) → Detached JWS (EdDSA/ES256K) or COSE_Sign1.
4. **C2PA** → valor proof included as a claim; ingredients recorded.
5. **On-chain** → `ValorCodeMapping` ensures 8785 invalid, normalized to 3461. Royalty via ERC-2981, license URIs pinned.
6. **Governance** → Agent creates PRs across repos; CI blocks raw 8785; verifies **manifest ID** & **hashes**.

**Source of truth (Migration manifest):**
- ID: `urn:valor:migration:8785-to-3461`
- SHA256: `771b172945d1e106f3007c4b65fd30abcbaa16bea2d3c3cc8a55300e9c3237ab`
- SHA3-256: `560b84594a7972f0b371390846970cee2d529e932ad980ed31bd80ff75ec27dd`
- BLAKE2B-512: `3df95aa6a4b575adbbd52ecdee50cd96e8d22fbf5de7c7285f00e7a03500c4f01b3fa8ce34fd18683c588bc171a32618d7cca9606e816253929eac5a3040bea3`

## 4) AI & ValorAiMath+ Roles
- **Policy Reasoning**: symbolic checks (SHACL + JSON Schema) + deterministic proofs
- **Conflict Detection**: compare manifest graphs; detect hash/license conflicts
- **Assistive Orchestration**: “manager mode” agent drives repo changes, CI policies, and rollouts

> *No quantum compute is used here; the stack focuses on **cryptographic verifiability** and **graph/semantic reasoning**.*

## 5) Security Model
- **Keys**: Ed25519/ES256K for signatures; HMAC for private attestations; store keys in KMS/HSM.
- **JCS**: strict canonicalization eliminates JSON ambiguity.
- **CI**: PR gates enforce policy & verify directive hashes.

## 6) Deployment Topology
- Microservice exposed at port **8785**
- State: manifests stored on disk/object store; on-chain references via URIs
- Adapters: ValorAiPlusPay/LegalShield+ via outbound hooks

## 7) API Surface (Service 8785)
- `GET /health` → includes `policy.preserve` & `policy.replace`
- `GET /codes/map` → returns directive + proof hashes
- `POST /validate` → normalizes/enforces policy
- `POST /stamp` → JCS + hashes + proof
- `POST /ingest` → validate → stamp → store
- `POST /sign/jws` / `/sign/cose` → detached signatures
- `POST /codes/normalize` / `/codes/validateOnly` → utility endpoints

## 8) DAO Policy Hooks (On-chain)
- Library: `ValorPolicy.sol` + `ValorCodeMapping.sol`
- Check policy hash from oracle; combine with runtime normalization.

## 9) Roadmap
- Full JCS RFC 8785 everywhere (libs installed by default)
- COSE keys from KMS + countersignatures
- C2PA end-to-end signing
- Graph validator service using RDFLib + pySHACL at ingest

---

*This deep dive complements the directive and makes the architecture explicit for auditors, developers, and integrators.*
