# ADR-0002: Policy Migration 8785→3461
Decision: Make `8785` invalid globally; normalize to `3461`. Preserve `7226` as canonical. 