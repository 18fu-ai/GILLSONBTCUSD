# ADR-0001: Canonicalization & Proofs
Decision: Use RFC 8785 JCS + sha256/sha3-256/blake2b-512, plus optional JWS/COSE signatures. 