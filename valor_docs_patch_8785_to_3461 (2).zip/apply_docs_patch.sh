#!/usr/bin/env bash
set -euo pipefail
REPO_DIR="${1:-}"
if [ -z "$REPO_DIR" ]; then
  echo "Usage: $0 /path/to/service-repo" >&2
  exit 1
fi
mkdir -p "$REPO_DIR/docs" "$REPO_DIR/docs/diagrams" "$REPO_DIR/docs/adr"
rsync -a ./docs/ "$REPO_DIR/docs/"
echo "Docs patch applied to $REPO_DIR/docs"
