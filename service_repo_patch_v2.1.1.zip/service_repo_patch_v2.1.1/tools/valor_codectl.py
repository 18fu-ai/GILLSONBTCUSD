#!/usr/bin/env python3
"""
valor_codectl.py — fetch code policy from service and normalize input JSON.
"""
import os, sys, json, urllib.request

SERVICE = os.getenv("VALOR_SERVICE", "http://localhost:8785")

def fetch_map():
    with urllib.request.urlopen(f"{SERVICE}/codes/map", timeout=5) as r:
        return json.loads(r.read().decode("utf-8"))

def normalize(doc):
    req = urllib.request.Request(f"{SERVICE}/codes/normalize", method="POST")
    req.add_header("Content-Type", "application/json")
    data = json.dumps({"document": doc}).encode("utf-8")
    with urllib.request.urlopen(req, data=data, timeout=5) as r:
        return json.loads(r.read().decode("utf-8"))["document"]

if __name__ == "__main__":
    cmap = fetch_map()
    doc = json.load(sys.stdin)
    nd = normalize(doc)
    json.dump({"map": cmap, "normalized": nd}, sys.stdout, indent=2)
