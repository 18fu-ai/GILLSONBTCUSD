#!/usr/bin/env bash
set -euo pipefail
# Apply service v2.1.1 enhancements into current repo.
# Usage: ./apply_service_patch.sh /path/to/your/service/repo
REPO_DIR="${1:-}"
if [ -z "$REPO_DIR" ]; then
  echo "Usage: $0 /path/to/repo" >&2
  exit 1
fi
cd "$REPO_DIR"
# Copy in files (non-destructive: will overwrite existing with updated ones)
rsync -a --delete "/mnt/data/pr_branches_8785_to_3461/service_repo_patch_v2.1.1/service/" "./service/"
mkdir -p ./shapes ./tools ./.github ./examples
rsync -a "/mnt/data/pr_branches_8785_to_3461/service_repo_patch_v2.1.1/shapes/" "./shapes/"
rsync -a "/mnt/data/pr_branches_8785_to_3461/service_repo_patch_v2.1.1/tools/" "./tools/"
rsync -a "/mnt/data/pr_branches_8785_to_3461/service_repo_patch_v2.1.1/.github/" "./.github/"
rsync -a "/mnt/data/pr_branches_8785_to_3461/service_repo_patch_v2.1.1/examples/" "./examples/"
cp "/mnt/data/pr_branches_8785_to_3461/service_repo_patch_v2.1.1/README_ENHANCEMENTS.md" "./README_ENHANCEMENTS.md"
echo "Service patch applied. Run: cd service && pip install -r requirements.txt && uvicorn main:app --port 8785"
