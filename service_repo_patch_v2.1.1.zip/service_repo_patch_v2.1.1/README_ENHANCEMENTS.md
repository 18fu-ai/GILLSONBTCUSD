# EXPANDED Enhancements (v2.1.1)
- REST: +/codes/normalize, +/codes/validateOnly, version bump to 2.1.1
- SHACL: explicit disallow rules for 8785; allowlist 3461 & 7226
- ETL: `tools/etl_apply_migration.py` to rewrite legacy data
- CLI: `tools/valor_codectl.py` to fetch policy and normalize via service
- CI: GitHub Action to verify stamped migration manifest hash
- Demo: `examples/manifests/legacy_before.json` → `after_normalized.json` (produced)
- Proofs: JCS canonicalization + multi-hash retained
