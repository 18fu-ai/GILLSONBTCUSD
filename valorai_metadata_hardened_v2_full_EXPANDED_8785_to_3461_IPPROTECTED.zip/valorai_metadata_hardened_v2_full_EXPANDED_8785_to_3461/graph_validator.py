"""
graph_validator.py — RDF/SHACL validation for Valor ontology.
Requires: rdflib, pyshacl
"""
import sys, json
from pathlib import Path

def validate_graph(data_ttl: str, shapes_ttl: str) -> dict:
    try:
        from rdflib import Graph
        from pyshacl import validate
    except Exception as e:
        return {"ok": False, "error": "Missing 'rdflib' or 'pyshacl' packages", "detail": str(e)}
    data_g = Graph()
    data_g.parse(data=data_ttl, format="turtle")
    shapes_g = Graph()
    shapes_g.parse(data=shapes_ttl, format="turtle")
    conforms, results_graph, results_text = validate(data_g, shacl_graph=shapes_g, inference='rdfs', abort_on_first=False, meta_shacl=False, advanced=True)
    return {"ok": bool(conforms), "report": results_text}

if __name__ == "__main__":
    ttl_path = Path(sys.argv[1])
    shapes_path = Path(sys.argv[2])
    out = validate_graph(ttl_path.read_text(), shapes_path.read_text())
    print(json.dumps(out, indent=2))

# © 2025 That's Edutainment, LLC — ValorAi+® | ValorAiMathAVM™ | ValorPhysics+™
# All rights reserved. Trademarks: VALORAIPLUS® and associated marks.
# Use subject to license and access controls. Unauthorized use prohibited.
# Proof: urn:valor:migration:8785-to-3461
# SHA256: 771b172945d1e106f3007c4b65fd30abcbaa16bea2d3c3cc8a55300e9c3237ab
# SHA3-256: 560b84594a7972f0b371390846970cee2d529e932ad980ed31bd80ff75ec27dd
# BLAKE2b-512: 3df95aa6a4b575adbbd52ecdee50cd96e8d22fbf5de7c7285f00e7a03500c4f01b3fa8ce34fd18683c588bc171a32618d7cca9606e816253929eac5a3040bea3
