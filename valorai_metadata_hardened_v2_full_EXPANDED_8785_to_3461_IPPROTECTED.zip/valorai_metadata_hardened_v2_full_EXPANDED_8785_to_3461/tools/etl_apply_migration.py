#!/usr/bin/env python3
"""
etl_apply_migration.py — applies 8785->3461 mapping to NDJSON/JSON/CSV inputs.
Usage:
  python etl_apply_migration.py --in data.json --out data.fixed.json
  cat data.ndjson | python etl_apply_migration.py --ndjson > out.ndjson
"""
import sys, json, argparse, csv

MAPPING = {8785: 3461}

def norm_val(v):
    try:
        n = int(str(v), 10)
        return MAPPING.get(n, n)
    except Exception:
        return v

def fix_record(rec):
    # Apply common locations; add your own as needed
    if isinstance(rec, dict):
        a = rec.get("asset") or {}
        if "tokenId" in a:
            a["tokenId"] = str(norm_val(a["tokenId"]))
            rec["asset"] = a
        if "policy" in rec and isinstance(rec["policy"], dict) and "code" in rec["policy"]:
            rec["policy"]["code"] = norm_val(rec["policy"]["code"])
        if "codes" in rec and isinstance(rec["codes"], list):
            rec["codes"] = [norm_val(x) for x in rec["codes"]]
    return rec

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="in_path")
    ap.add_argument("--out", dest="out_path")
    ap.add_argument("--ndjson", action="store_true")
    args = ap.parse_args()

    if args.ndjson:
        for line in sys.stdin:
            if not line.strip():
                continue
            rec = json.loads(line)
            rec = fix_record(rec)
            sys.stdout.write(json.dumps(rec, ensure_ascii=False) + "\n")
        return

    if not args.in_path:
        sys.exit("Provide --in file or use --ndjson with stdin")

    data = json.load(open(args.in_path, "r", encoding="utf-8"))
    if isinstance(data, list):
        data = [fix_record(x) for x in data]
    else:
        data = fix_record(data)

    if args.out_path:
        json.dump(data, open(args.out_path, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    else:
        print(json.dumps(data, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()

# © 2025 That's Edutainment, LLC — ValorAi+® | ValorAiMathAVM™ | ValorPhysics+™
# All rights reserved. Trademarks: VALORAIPLUS® and associated marks.
# Use subject to license and access controls. Unauthorized use prohibited.
# Proof: urn:valor:migration:8785-to-3461
# SHA256: 771b172945d1e106f3007c4b65fd30abcbaa16bea2d3c3cc8a55300e9c3237ab
# SHA3-256: 560b84594a7972f0b371390846970cee2d529e932ad980ed31bd80ff75ec27dd
# BLAKE2b-512: 3df95aa6a4b575adbbd52ecdee50cd96e8d22fbf5de7c7285f00e7a03500c4f01b3fa8ce34fd18683c588bc171a32618d7cca9606e816253929eac5a3040bea3
