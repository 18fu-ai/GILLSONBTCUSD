#!/usr/bin/env python3
import json, hashlib
from pathlib import Path
from rfc8785_jcs import canonicalize

# normalization (mirror service logic for tokenId only in this demo)
def norm_val(v):
    try:
        n = int(str(v), 10)
        return 3461 if n == 8785 else n
    except Exception:
        return v

doc = json.loads(Path("examples/manifests/legacy_before.json").read_text())
doc["asset"]["tokenId"] = str(norm_val(doc["asset"]["tokenId"]))

# stamp (simulate service /stamp)
copy = json.loads(json.dumps(doc))
copy.pop("proof", None)
cjson = canonicalize(copy)
hashes = {
    "sha256": hashlib.sha256(cjson).hexdigest(),
    "sha3_256": hashlib.sha3_256(cjson).hexdigest(),
    "blake2b_512": hashlib.blake2b(cjson, digest_size=64).hexdigest(),
}
doc.setdefault("manifest", {}).setdefault("contentHash", {}).update(hashes)
doc["proof"] = {"canonicalization":"JCS (RFC 8785)","algorithm":["sha256","sha3-256","blake2b-512"],"hashes":hashes}

Path("examples/manifests/after_normalized.json").write_text(json.dumps(doc, indent=2))
print(json.dumps({"normalized_tokenId": doc["asset"]["tokenId"], "hashes": hashes}, indent=2))

# © 2025 That's Edutainment, LLC — ValorAi+® | ValorAiMathAVM™ | ValorPhysics+™
# All rights reserved. Trademarks: VALORAIPLUS® and associated marks.
# Use subject to license and access controls. Unauthorized use prohibited.
# Proof: urn:valor:migration:8785-to-3461
# SHA256: 771b172945d1e106f3007c4b65fd30abcbaa16bea2d3c3cc8a55300e9c3237ab
# SHA3-256: 560b84594a7972f0b371390846970cee2d529e932ad980ed31bd80ff75ec27dd
# BLAKE2b-512: 3df95aa6a4b575adbbd52ecdee50cd96e8d22fbf5de7c7285f00e7a03500c4f01b3fa8ce34fd18683c588bc171a32618d7cca9606e816253929eac5a3040bea3
