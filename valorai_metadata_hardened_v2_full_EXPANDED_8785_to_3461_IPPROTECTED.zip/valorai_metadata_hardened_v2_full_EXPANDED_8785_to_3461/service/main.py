"""
ValorAi+ Metadata Service — REST microservice (ingest → validate → stamp → store → query)
Now enforces global code policy: 8785 → 3461 (exclusive), 7226 preserved.
"""
import os, json, time, uuid, hashlib
from pathlib import Path
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional, Any, Dict

from rfc8785_jcs import canonicalize, STRICT as JCS_STRICT
from signature_suite import jws_detached, cose_sign1_detached

STORAGE_DIR = Path(os.getenv("STORAGE_DIR", "./_store"))
STORAGE_DIR.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="ValorAi+ Metadata Service", version="2.1.1")

# ---- Global code policy (from stamped directive: urn:valor:migration:8785-to-3461)
CANON_CODES = {"7226"}                    # preserved/untouched
REPLACEMENTS = {8785: 3461}               # exclusive replacement
REPLACEMENT_SET = set(REPLACEMENTS.keys())

def normalize_codes_in_doc(doc: dict) -> dict:
    """
    Enforce exclusive replacement 8785 -> 3461 and keep 7226 canonical.
    Adjust paths to your schema as needed.
    """
    def norm_val(v):
        try:
            n = int(str(v), 10)
            return REPLACEMENTS.get(n, n)
        except Exception:
            return v

    asset = doc.get("asset") or {}
    if "tokenId" in asset:
        asset["tokenId"] = str(norm_val(asset["tokenId"]))
        doc["asset"] = asset

    if "policy" in doc and isinstance(doc["policy"], dict) and "code" in doc["policy"]:
        doc["policy"]["code"] = norm_val(doc["policy"]["code"])

    if "codes" in doc and isinstance(doc["codes"], list):
        doc["codes"] = [norm_val(x) for x in doc["codes"]]
    return doc

def reject_if_forbidden(doc: dict):
    """
    If the document still contains forbidden code 8785 post-normalization, reject it.
    """
    def has_forbidden(v):
        try:
            return int(str(v), 10) in REPLACEMENT_SET
        except Exception:
            return False
    if "asset" in doc and has_forbidden(doc["asset"].get("tokenId")):
        raise HTTPException(status_code=400, detail="Code 8785 is invalid (replaced by 3461).")
    if "policy" in doc and has_forbidden((doc["policy"] or {}).get("code")):
        raise HTTPException(status_code=400, detail="Code 8785 is invalid (replaced by 3461).")
    if any(has_forbidden(x) for x in (doc.get("codes") or [])):
        raise HTTPException(status_code=400, detail="Code 8785 is invalid (replaced by 3461).")

class ManifestIn(BaseModel):
    document: Dict[str, Any]

class SignReq(BaseModel):
    payload: str  # raw JSON string or plain text
    alg: str      # "EdDSA" or "ES256K"
    key_pem: str
    kid: Optional[str] = None

@app.get("/health")
def health():
    return {
        "ok": True,
        "jcs_strict": JCS_STRICT,
        "policy": {
            "preserve": sorted(CANON_CODES),
            "replace": {str(k): v for k, v in REPLACEMENTS.items()},
        },
    }

@app.get("/codes/map")
def code_map():
    return {
        "preserve": sorted(CANON_CODES),
        "replace": {str(k): v for k, v in REPLACEMENTS.items()},
        "manifest_id": "urn:valor:migration:8785-to-3461",
        "proof_hashes": {
            "sha256":  "771b172945d1e106f3007c4b65fd30abcbaa16bea2d3c3cc8a55300e9c3237ab",
            "sha3_256":"560b84594a7972f0b371390846970cee2d529e932ad980ed31bd80ff75ec27dd",
            "blake2b_512": "3df95aa6a4b575adbbd52ecdee50cd96e8d22fbf5de7c7285f00e7a03500c4f01b3fa8ce34fd18683c588bc171a32618d7cca9606e816253929eac5a3040bea3"
        }
    }

@app.post("/validate")
def validate_endpoint(m: ManifestIn):
    doc = normalize_codes_in_doc(m.document)
    reject_if_forbidden(doc)
    # Minimal structure checks
    required = ["@context","type","asset","manifest","license","royalty"]
    missing = [k for k in required if k not in doc]
    if missing:
        raise HTTPException(status_code=400, detail={"missing": missing})
    return {"ok": True, "migrations_applied": list(REPLACEMENTS.keys())}

@app.post("/stamp")
def stamp_endpoint(m: ManifestIn):
    doc = normalize_codes_in_doc(m.document)
    reject_if_forbidden(doc)
    # Exclude proof when building canonical hash input
    doc_copy = json.loads(json.dumps(doc))
    proof = doc_copy.pop("proof", None)
    cjson = canonicalize(doc_copy)
    hashes = {
        "sha256": hashlib.sha256(cjson).hexdigest(),
        "sha3_256": hashlib.sha3_256(cjson).hexdigest(),
        "blake2b_512": hashlib.blake2b(cjson, digest_size=64).hexdigest(),
    }
    doc.setdefault("manifest", {}).setdefault("contentHash", {}).update(hashes)
    now = int(time.time())
    p = doc.get("proof", {}) or {}
    p.setdefault("algorithm", ["sha256","sha3-256","blake2b-512"])
    p.setdefault("canonicalization", "JCS (RFC 8785)")
    p.setdefault("hashes", {}).update(hashes)
    p["createdUTC"] = now
    doc["proof"] = p
    return {"ok": True, "document": doc, "hashes": hashes, "migrations_applied": list(REPLACEMENTS.keys())}

@app.post("/store")
def store_endpoint(m: ManifestIn):
    doc = m.document
    jid = str(uuid.uuid4())
    (STORAGE_DIR / f"{jid}.json").write_text(json.dumps(doc, indent=2), encoding="utf-8")
    return {"ok": True, "id": jid}

@app.get("/query")
def query_endpoint(id: str):
    p = STORAGE_DIR / f"{id}.json"
    if not p.exists():
        raise HTTPException(status_code=404, detail="Not found")
    return json.loads(p.read_text())

@app.post("/ingest")
def ingest(m: ManifestIn):
    v = validate_endpoint(m)
    s = stamp_endpoint(ManifestIn(document=m.document))
    doc = s["document"]
    st = store_endpoint(ManifestIn(document=doc))
    return {
        "ok": True,
        "id": st["id"],
        "hashes": s["hashes"],
        "migrations_applied": s.get("migrations_applied", []),
    }

@app.post("/sign/jws")
def sign_jws(req: SignReq):
    payload = req.payload.encode("utf-8")
    try:
        compact = jws_detached(payload, req.alg, req.key_pem.encode("utf-8"), kid=req.kid)
        return {"ok": True, "compact_detached": compact}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/sign/cose")
def sign_cose(req: SignReq):
    payload = req.payload.encode("utf-8")
    try:
        blob = cose_sign1_detached(payload, req.alg, req.key_pem.encode("utf-8"))
        return {"ok": True, "cose_sign1_hex": blob.hex()}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/codes/normalize")
def codes_normalize(m: ManifestIn):
    doc = normalize_codes_in_doc(m.document)
    return {"ok": True, "document": doc}

@app.post("/codes/validateOnly")
def codes_validate_only(m: ManifestIn):
    doc = normalize_codes_in_doc(m.document)
    try:
        reject_if_forbidden(doc)
        return {"ok": True, "normalized": doc}
    except HTTPException as e:
        raise

# © 2025 That's Edutainment, LLC — ValorAi+® | ValorAiMathAVM™ | ValorPhysics+™
# All rights reserved. Trademarks: VALORAIPLUS® and associated marks.
# Use subject to license and access controls. Unauthorized use prohibited.
# Proof: urn:valor:migration:8785-to-3461
# SHA256: 771b172945d1e106f3007c4b65fd30abcbaa16bea2d3c3cc8a55300e9c3237ab
# SHA3-256: 560b84594a7972f0b371390846970cee2d529e932ad980ed31bd80ff75ec27dd
# BLAKE2b-512: 3df95aa6a4b575adbbd52ecdee50cd96e8d22fbf5de7c7285f00e7a03500c4f01b3fa8ce34fd18683c588bc171a32618d7cca9606e816253929eac5a3040bea3
