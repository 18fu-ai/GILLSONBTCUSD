#!/usr/bin/env bash
set -euo pipefail
IMAGE=${1:-valoraiplus2e/instant-api:dev}
docker build -t "$IMAGE" .
docker run --rm -p 9000:9000 "$IMAGE"
