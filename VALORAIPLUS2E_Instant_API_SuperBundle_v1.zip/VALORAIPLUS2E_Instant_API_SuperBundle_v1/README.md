# 🌌 VALORAIPLUS2E — Instant ML/LLM API SuperBundle

**Zero-wait** demo: unzip, run, and hit **http://127.0.0.1:9000/docs**.  
Adds **/batch_generate** and an **OpenAI-style** endpoint (`/v1/chat/completions`) on top of the Instant API.

## 30-second launch
```bash
python3 -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt
uvicorn src.serving.fastapi_server:app --reload --port 9000
# or
bash scripts/run_docker.sh
```

## Endpoints
- `GET /health` — status
- `POST /generate` — single generate
- `POST /batch_generate` — list of prompts → list of texts
- `POST /v1/chat/completions` — minimal OpenAI-style
- `POST /predict_tabular` — demo RF classifier

## Docker — GHCR buildx
- GitHub Actions → **Build & Publish Instant API (GHCR, multi-arch)**
  - `image`: `ghcr.io/your-org/valoraiplus2e-instant-api`
  - `tag`: `v1`

© 2025 VALORAIPLUS® — That’s Edutainment, LLC.
