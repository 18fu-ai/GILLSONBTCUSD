from fastapi import FastAPI
from pydantic import BaseModel
import os, json

# LLM setup (tiny model with fallback)
LLM_MODEL_NAME = os.getenv("LLM_MODEL_NAME","sshleifer/tiny-gpt2")
USE_FALLBACK = False
tok=None; model=None
try:
    from transformers import AutoTokenizer, AutoModelForCausalLM, set_seed
    tok = AutoTokenizer.from_pretrained(LLM_MODEL_NAME, use_fast=True)
    if tok.pad_token is None: tok.pad_token = tok.eos_token
    model = AutoModelForCausalLM.from_pretrained(LLM_MODEL_NAME)
    model.eval(); set_seed(42)
except Exception as e:
    USE_FALLBACK=True; print("[VALORAIPLUS2E] tiny model unavailable; using fallback.", e)

# Tabular
import joblib, numpy as np
from pathlib import Path
TABULAR_PATH = Path("runs/tabular_model.joblib")
tabular_model = joblib.load(TABULAR_PATH) if TABULAR_PATH.exists() else None

app = FastAPI(title="VALORAIPLUS2E Instant API SuperBundle", version="1.0.0")

class GenerateReq(BaseModel):
    prompt: str
    max_new_tokens: int = 48

class BatchGenerateReq(BaseModel):
    prompts: list[str]
    max_new_tokens: int = 48

class TabularReq(BaseModel):
    f1: float; f2: float; f3: float

# OpenAI-style schema (minimal)
class ChatMessage(BaseModel):
    role: str
    content: str

class ChatReq(BaseModel):
    model: str | None = None
    messages: list[ChatMessage]
    max_tokens: int = 64
    temperature: float = 0.7

@app.get("/health")
def health():
    return {"status":"ok","brand":"VALORAIPLUS2E","llm_fallback":USE_FALLBACK,"tabular_loaded": tabular_model is not None}

def _generate_text(prompt: str, max_new_tokens: int):
    if USE_FALLBACK or tok is None or model is None:
        return f"{prompt}\n\n[VALORAIPLUS2E DEMO]: truth anchored • consequence measured • design conscious"
    import torch
    ids = tok(prompt, return_tensors="pt")
    with torch.no_grad():
        out = model.generate(**ids, max_new_tokens=max_new_tokens)
    return tok.decode(out[0], skip_special_tokens=True)

@app.post("/generate")
def generate(req: GenerateReq):
    return {"text": _generate_text(req.prompt, req.max_new_tokens)}

@app.post("/batch_generate")
def batch_generate(req: BatchGenerateReq):
    outputs = [_generate_text(p, req.max_new_tokens) for p in req.prompts]
    return {"texts": outputs}

# OpenAI-style minimal chat completions
@app.post("/v1/chat/completions")
def chat_completions(req: ChatReq):
    # build a simple prompt from last user message
    user_msgs = [m.content for m in req.messages if m.role.lower()=="user"]
    last = user_msgs[-1] if user_msgs else ""
    completion = _generate_text(last, req.max_tokens)
    return {
        "id": "valoraiplus2e-chatcmpl-1",
        "object": "chat.completion",
        "model": req.model or LLM_MODEL_NAME,
        "choices": [
            {"index":0, "message":{"role":"assistant","content": completion}, "finish_reason":"stop"}
        ]
    }

@app.post("/predict_tabular")
def predict_tabular(req: TabularReq):
    if tabular_model is None:
        return {"error":"tabular model not loaded"}
    X = [[req.f1, req.f2, req.f3]]
    pred = int(tabular_model.predict(X)[0])
    prob = None
    try:
        prob = float(tabular_model.predict_proba(X)[0][pred])
    except Exception:
        pass
    return {"label": pred, "prob": prob}
