#!/usr/bin/env bash
set -euo pipefail

# Requires: gh (GitHub CLI), git, jq, rsync, unzip, curl

CFG="agent_config.json"
if [ ! -f "$CFG" ]; then
  echo "agent_config.json missing"; exit 1
fi

BASE=$(jq -r .base_branch "$CFG")
ASSIGNEES=$(jq -r '.assignees|join(",")' "$CFG")
REVIEWERS=$(jq -r '.reviewers|join(",")' "$CFG")
LABELS=$(jq -r '.labels|join(",")' "$CFG")
AUTO_MERGE=$(jq -r '.auto_merge' "$CFG")
WEBHOOK=$(jq -r '.webhook_url' "$CFG")

git config --global user.name $(jq -r .git_user_name "$CFG")
git config --global user.email $(jq -r .git_user_email "$CFG")

# Artifacts
SERVICE_PATCH_ZIP=$(jq -r .artifacts.service_patch_zip "$CFG")
ONCHAIN_PATCH_ZIP=$(jq -r .artifacts.onchain_patch_zip "$CFG")
DATA_PATCH_ZIP=$(jq -r .artifacts.data_patch_zip "$CFG")
DOCS_PATCH_ZIP=$(jq -r .artifacts.docs_patch_zip "$CFG")

# Branch names
BR_SRV=$(jq -r .service 'branches.json')
BR_ONC=$(jq -r .onchain 'branches.json')
BR_DAT=$(jq -r .data 'branches.json')
BR_DOC=$(jq -r .docs 'branches.json')

# Commit messages
CM_SRV=$(jq -r .service 'commits.json')
CM_ONC=$(jq -r .onchain 'commits.json')
CM_DAT=$(jq -r .data 'commits.json')
CM_DOC=$(jq -r .docs 'commits.json')

create_pr() { # path slug branch title body
  local REPO_DIR="$1"; shift
  local SLUG="$1"; shift
  local BR="$1"; shift
  local TITLE="$1"; shift
  local BODY="$1"; shift
  pushd "$REPO_DIR" >/dev/null
  gh repo set-default "$SLUG" >/dev/null 2>&1 || true
  local URL=$(gh pr create --base "$BASE" --head "$BR" --title "$TITLE" --body-file "$BODY" --label "$LABELS" --reviewer "$REVIEWERS" --assignee "$ASSIGNEES")
  echo "$URL"
  if [ "$AUTO_MERGE" = "true" ]; then
    gh pr merge --auto --merge "$URL" || true
  fi
  if [ -n "$WEBHOOK" ] && [ "$WEBHOOK" != "null" ]; then
    curl -s -X POST -H "Content-Type: application/json" -d "{\"event\":\"pr_opened\",\"url\":\"$URL\",\"branch\":\"$BR\"}" "$WEBHOOK" >/dev/null || true
  fi
  popd >/dev/null
}

apply_pack() { # repo_path zip_rel_path subdir_from_zip commit_msg branch
  local REPO_DIR="$1"; shift
  local ZIP="$1"; shift
  local SUB="$2"; shift
  local CM="$3"; shift
  local BR="$4"; shift
  local TMP=$(mktemp -d)
  unzip -q "$ZIP" -d "$TMP"
  pushd "$REPO_DIR"
  git checkout -B "$BR" "$BASE"
  rsync -a "$TMP/$SUB/" "./"  # copy contents
  git add -A
  git commit -m "$CM" || true
  git push -u origin "$BR" || true
  popd
  rm -rf "$TMP"
}

# --- SERVICE ---
SRV_PATH=$(jq -r .service_repo.local_path "$CFG")
SRV_SLUG=$(jq -r .service_repo.slug "$CFG")
apply_pack "$SRV_PATH" "$SERVICE_PATCH_ZIP" "service_repo_patch_v2.1.1" "$CM_SRV" "$BR_SRV"
URL_SRV=$(create_pr "$SRV_PATH" "$SRV_SLUG" "$BR_SRV" "feat(service): policy 8785→3461 v2.1.1" "PR_SERVICE.md")
echo "Service PR: $URL_SRV"

# --- ONCHAIN ---
ONC_PATH=$(jq -r .onchain_repo.local_path "$CFG")
ONC_SLUG=$(jq -r .onchain_repo.slug "$CFG")
apply_pack "$ONC_PATH" "$ONCHAIN_PATCH_ZIP" "onchain_policy_gate_8785_to_3461" "$CM_ONC" "$BR_ONC"
URL_ONC=$(create_pr "$ONC_PATH" "$ONC_SLUG" "$BR_ONC" "feat(onchain): gate 8785, normalize 3461" "PR_ONCHAIN.md")
echo "On-chain PR: $URL_ONC"

# --- DATA / ETL ---
DAT_PATH=$(jq -r .data_repo.local_path "$CFG")
DAT_SLUG=$(jq -r .data_repo.slug "$CFG")
apply_pack "$DAT_PATH" "$DATA_PATCH_ZIP" "data_etl_repo_patch" "$CM_DAT" "$BR_DAT"
URL_DAT=$(create_pr "$DAT_PATH" "$DAT_SLUG" "$BR_DAT" "feat(data): ETL migration 8785→3461" "PR_DATA.md")
echo "Data PR: $URL_DAT"

# --- DOCS (apply Deep Dive to service repo) ---
# Reuse service repo to host docs
apply_pack "$SRV_PATH" "$DOCS_PATCH_ZIP" "" "$CM_DOC" "$BR_DOC"
URL_DOC=$(create_pr "$SRV_PATH" "$SRV_SLUG" "$BR_DOC" "docs: ValorAi+ Architecture Deep Dive" "PR_DOCS.md")
echo "Docs PR: $URL_DOC"

echo "All PRs triggered."
