# Valor Agent Manager — Full Automation (8785 → 3461)
- Creates four PRs: service, on-chain, data/ETL, and docs (Architecture Deep Dive)
- Auto-merge optional; PR webhook callback optional
- Edit `agent_config.json` then run `./agent_auto_pr.sh`

Requirements: gh, git, jq, rsync, unzip, curl
