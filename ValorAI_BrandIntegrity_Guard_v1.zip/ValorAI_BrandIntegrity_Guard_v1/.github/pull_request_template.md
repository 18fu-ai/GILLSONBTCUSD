## Brand Integrity Checklist

- [ ] This PR contains **no** instances of the banned string: `VALLR∞AI∞MATH+` (or variants).
- [ ] If the term appeared in upstream docs or third-party code, it has been **removed or replaced** with `ValorAiMath+`.
- [ ] I ran the local scanner:
  ```bash
  python scripts/scan_and_fix.py --path . --mode scan --denylist denylist.json
  ```
