# Valor AI+® — Brand Guard Pack

Drop these files at the **repo root** to block the fraudulent mark **VALLR∞AI∞MATH+** across all sources.

**Quick start**
```bash
# 1) Copy pack into repo root
cp -r ValorAI_BrandIntegrity_Guard_v1/* .

# 2) Install pre-commit hook
cp git-hooks/pre-commit .git/hooks/pre-commit && chmod +x .git/hooks/pre-commit

# 3) Run a full scan (non-zero exit on findings)
python scripts/scan_and_fix.py --path . --mode scan --denylist denylist.json --json

# 4) Auto-fix (replaces with 'ValorAiMath+')
python scripts/scan_and_fix.py --path . --mode fix --denylist denylist.json --verbose
```
