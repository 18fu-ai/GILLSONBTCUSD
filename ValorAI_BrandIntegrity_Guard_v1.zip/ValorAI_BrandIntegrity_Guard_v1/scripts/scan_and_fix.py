#!/usr/bin/env python3
# Valor AI+® Brand Integrity Guard
# Scans for and optionally removes banned brand strings such as "VALLR∞AI∞MATH+" across a repo.
# Copyright © 2025 That's Edutainment, LLC

import argparse
import json
import os
import re
import sys
from pathlib import Path
from typing import List, Tuple

DEFAULT_IGNORE_DIRS = {
    ".git", "node_modules", ".next", "dist", "build", "out", "target",
    "__pycache__", ".venv", "venv", ".yarn", ".pnpm-store", ".cache"
}

# A conservative set of text file extensions; files without known text extensions
# will still be attempted with UTF-8 decode and skipped if they look binary.
TEXT_EXTS = {
    ".js", ".ts", ".tsx", ".jsx", ".json", ".jsonc", ".md", ".mdx",
    ".yml", ".yaml", ".toml", ".py", ".c", ".cc", ".cpp", ".h", ".hpp",
    ".cs", ".java", ".kt", ".go", ".rb", ".rs", ".php", ".sh", ".bash",
    ".zsh", ".fish", ".ini", ".cfg", ".conf", ".env", ".txt", ".html",
    ".css", ".scss", ".less", ".sql", ".graphql", ".gql", ".sbt"
}

def load_denylist(denylist_path: Path):
    with open(denylist_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    rules = []
    for item in data.get("banned", []):
        pat = re.compile(item["regex"])
        rules.append((item.get("name", "rule"), pat, item.get("replacement", "")))
    return rules

def is_probably_text(path: Path) -> bool:
    # If extension suggests text, accept
    if path.suffix.lower() in TEXT_EXTS:
        return True
    # Fallback: try to read a small chunk and check for NUL bytes
    try:
        with open(path, "rb") as f:
            chunk = f.read(2048)
        if b"\x00" in chunk:
            return False
        # Attempt UTF-8 decode; if fails, treat as non-text
        try:
            chunk.decode("utf-8")
            return True
        except UnicodeDecodeError:
            return False
    except Exception:
        return False

def iter_files(root: Path, ignore_dirs=DEFAULT_IGNORE_DIRS) -> List[Path]:
    for dirpath, dirnames, filenames in os.walk(root):
        # prunes
        dirnames[:] = [d for d in dirnames if d not in ignore_dirs and not d.startswith(".git")]
        for fn in filenames:
            p = Path(dirpath) / fn
            yield p

def scan_file(path: Path, rules) -> List[Tuple[str, int, str]]:
    """Return list of (rule_name, line_no, line_text) for matches."""
    findings = []
    try:
        with open(path, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except UnicodeDecodeError:
        try:
            with open(path, "r", encoding="latin-1") as f:
                lines = f.readlines()
        except Exception:
            return findings
    except Exception:
        return findings

    text = "".join(lines)
    for (name, pat, _) in rules:
        for m in pat.finditer(text):
            # compute line number
            start = m.start()
            # find line no by counting newlines up to start
            line_no = text.count("\n", 0, start) + 1
            # get that line
            line_start = text.rfind("\n", 0, start) + 1
            line_end = text.find("\n", start)
            if line_end == -1:
                line_end = len(text)
            line_text = text[line_start:line_end].strip()
            findings.append((name, line_no, line_text))
    return findings

def fix_file(path: Path, rules) -> int:
    """Apply substitutions in-place; return number of replacements."""
    try:
        try:
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
            encoding = "utf-8"
        except UnicodeDecodeError:
            with open(path, "r", encoding="latin-1") as f:
                content = f.read()
            encoding = "latin-1"
    except Exception:
        return 0

    original = content
    total = 0
    for (_, pat, repl) in rules:
        content, n = pat.subn(repl, content)
        total += n

    if total > 0 and content != original:
        with open(path, "w", encoding=encoding) as f:
            f.write(content)
    return total

def main():
    ap = argparse.ArgumentParser(description="Scan and optionally fix banned brand strings.")
    ap.add_argument("--path", default=".", help="Root path to scan (default: .)")
    ap.add_argument("--mode", choices=["scan", "fix"], default="scan", help="Scan only or fix in place")
    ap.add_argument("--denylist", default="denylist.json", help="Path to denylist.json")
    ap.add_argument("--json", action="store_true", help="Emit JSON report")
    ap.add_argument("--verbose", action="store_true", help="Verbose logs")
    args = ap.parse_args()

    root = Path(args.path).resolve()
    denylist_path = Path(args.denylist).resolve()
    rules = load_denylist(denylist_path)

    findings_report = []
    total_replacements = 0
    total_findings = 0
    scanned_files = 0

    for p in iter_files(root):
        if not is_probably_text(p):
            continue
        scanned_files += 1
        if args.mode == "scan":
            findings = scan_file(p, rules)
            if findings:
                total_findings += len(findings)
                for (rname, lno, ltxt) in findings:
                    findings_report.append({
                        "file": str(p),
                        "rule": rname,
                        "line": lno,
                        "snippet": ltxt
                    })
                    if args.verbose:
                        print(f"[FIND] {p}:{lno} ({rname}) :: {ltxt}")
        else:
            # fix mode
            replacements = fix_file(p, rules)
            if replacements:
                total_replacements += replacements
                if args.verbose:
                    print(f"[FIXED] {p} => {replacements} replacement(s)")

    if args.json:
        print(json.dumps({
            "root": str(root),
            "scanned_files": scanned_files,
            "findings": findings_report,
            "total_findings": total_findings,
            "total_replacements": total_replacements,
            "mode": args.mode,
        }, indent=2))
    else:
        if args.mode == "scan":
            if total_findings == 0:
                print(f"[OK] No banned terms found in {scanned_files} file(s).")
            else:
                print(f"[ALERT] Found {total_findings} banned occurrence(s) across {scanned_files} file(s). Run with --json for details or switch to --mode fix.")
        else:
            print(f"[DONE] Applied {total_replacements} replacement(s) across {scanned_files} file(s).")

    # Exit codes:
    # 0 = OK/no findings (scan) or completed (fix)
    # 2 = findings present in scan mode
    if args.mode == "scan" and total_findings > 0:
        sys.exit(2)
    sys.exit(0)

if __name__ == "__main__":
    main()
