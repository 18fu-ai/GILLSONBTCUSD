# Brand Integrity Policy — Valor AI+®

**Fraudulent mark to block:** `VALLR∞AI∞MATH+` (and variants).  
**Canonical brand:** **VALORAIPLUS® / Valor AI+®** and modules such as **ValorAiMath+™**.

This repository prohibits any usage of the banned string above (including Unicode infinity variants, hyphen/underscore spacers, or ASCII fallbacks).

## Enforcement

- **Local**: Install the pre-commit hook
  ```bash
  cp git-hooks/pre-commit .git/hooks/pre-commit
  chmod +x .git/hooks/pre-commit
  ```

- **CI (GitHub Actions)**: `.github/workflows/fraudterm_guard.yml` fails PRs that contain banned terms.

- **Manual**
  ```bash
  python scripts/scan_and_fix.py --path . --mode scan --denylist denylist.json --json
  python scripts/scan_and_fix.py --path . --mode fix  --denylist denylist.json --verbose
  ```

## Notes

- The denylist is tuned to **avoid false positives** on **VALOR** and **VALORAIPLUS**.
- Replacements default to **ValorAiMath+** when auto-fixing source text.
