# Keys (Ed25519 & secp256k1)

This folder intentionally contains **no private keys**.

## Generate locally (OpenSSL)

Ed25519:
  openssl genpkey -algorithm Ed25519 -out ed25519_private.pem
  openssl pkey -in ed25519_private.pem -pubout -out ed25519_public.pem

secp256k1:
  openssl ecparam -name secp256k1 -genkey -noout -out secp256k1_private.pem
  openssl ec -in secp256k1_private.pem -pubout -out secp256k1_public.pem

## Secure storage
- Prefer HSM/KMS (GCP KMS, AWS KMS, Azure Key Vault, HashiCorp Vault).
- Never commit private keys to git or bundles.
