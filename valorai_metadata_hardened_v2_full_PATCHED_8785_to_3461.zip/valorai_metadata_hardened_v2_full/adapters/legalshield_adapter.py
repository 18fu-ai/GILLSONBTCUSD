"""
legalshield_adapter.py — outbound hooks to ValorAiPlus LegalShield+.
"""
import os, json, urllib.request
LEGALSHIELD_URL = os.getenv("LEGALSHIELD_URL", "https://api.legalshield.valoraiplus.local/file")
LEGALSHIELD_KEY = os.getenv("LEGALSHIELD_KEY", "REPLACE_ME")

def file_manifest(manifest: dict) -> dict:
    req = urllib.request.Request(LEGALSHIELD_URL, method="POST")
    req.add_header("Content-Type", "application/json")
    req.add_header("Authorization", f"Bearer {LEGALSHIELD_KEY}")
    data = json.dumps({"manifest": manifest}).encode("utf-8")
    with urllib.request.urlopen(req, data=data, timeout=10) as r:
        return json.loads(r.read().decode("utf-8"))
