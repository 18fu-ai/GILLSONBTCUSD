"""
valoraipluspay_adapter.py — outbound hooks to ValorAiPlusPay.
"""
import os, json, urllib.request

VALORPAY_URL = os.getenv("VALORPAY_URL", "https://api.valoraipluspay.local/ingest")
VALORPAY_KEY = os.getenv("VALORPAY_KEY", "REPLACE_ME")

def send_manifest(manifest: dict) -> dict:
    req = urllib.request.Request(VALORPAY_URL, method="POST")
    req.add_header("Content-Type", "application/json")
    req.add_header("Authorization", f"Bearer {VALORPAY_KEY}")
    data = json.dumps({"manifest": manifest}).encode("utf-8")
    with urllib.request.urlopen(req, data=data, timeout=10) as r:
        return json.loads(r.read().decode("utf-8"))
