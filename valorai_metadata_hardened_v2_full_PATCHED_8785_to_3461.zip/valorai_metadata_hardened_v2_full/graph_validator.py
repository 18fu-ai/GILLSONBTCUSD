"""
graph_validator.py — RDF/SHACL validation for Valor ontology.
Requires: rdflib, pyshacl
"""
import sys, json
from pathlib import Path

def validate_graph(data_ttl: str, shapes_ttl: str) -> dict:
    try:
        from rdflib import Graph
        from pyshacl import validate
    except Exception as e:
        return {"ok": False, "error": "Missing 'rdflib' or 'pyshacl' packages", "detail": str(e)}
    data_g = Graph()
    data_g.parse(data=data_ttl, format="turtle")
    shapes_g = Graph()
    shapes_g.parse(data=shapes_ttl, format="turtle")
    conforms, results_graph, results_text = validate(data_g, shacl_graph=shapes_g, inference='rdfs', abort_on_first=False, meta_shacl=False, advanced=True)
    return {"ok": bool(conforms), "report": results_text}

if __name__ == "__main__":
    ttl_path = Path(sys.argv[1])
    shapes_path = Path(sys.argv[2])
    out = validate_graph(ttl_path.read_text(), shapes_path.read_text())
    print(json.dumps(out, indent=2))
