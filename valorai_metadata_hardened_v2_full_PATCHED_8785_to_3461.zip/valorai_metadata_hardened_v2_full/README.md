# ValorAi+ Hardened Proofs v2 (Strict JCS + Ed25519/ES256K + REST + C2PA + DAO hooks)

**This package upgrades your pillar to full-on, spec-grade interop.**
(See README in previous step for full commands.)

- Strict JCS via `rfc8785`/`jcs` (fallback included).
- Detached signatures: JWS (EdDSA/ES256K) & COSE_Sign1.
- RDF/SHACL validator.
- REST microservice endpoints.
- C2PA ingredient chain example.
- DAO policy schema + on-chain helper.
