"""
rfc8785_jcs.py — Strict JCS canonicalization wrapper.
Priority:
  1) Use RFC 8785 libs if installed: `rfc8785` or `jcs`
  2) Fallback to local minimal canonicalizer (NOT fully compliant for all numeric edge cases)

Refs:
- RFC 8785 (JCS): https://www.rfc-editor.org/rfc/rfc8785
"""
from typing import Any
import json, math

try:
    import rfc8785 as _rfc8785  # pip install rfc8785
    def canonicalize(data: Any) -> bytes:
        return _rfc8785.canonicalize(data)
    STRICT = True
except Exception:
    try:
        import jcs as _jcs  # pip install jcs
        def canonicalize(data: Any) -> bytes:
            return _jcs.canonicalize(data)
        STRICT = True
    except Exception:
        STRICT = False
        def _encode_number(x: float) -> str:
            if not math.isfinite(x):
                raise ValueError("Non-finite numbers are not permitted by I-JSON/JCS")
            if x == 0:
                return "0"
            if float(int(x)) == x and abs(x) < 2**53:
                return str(int(x))
            s = format(x, ".15g")
            return s.replace("E", "e")

        def _canon(obj) -> str:
            if obj is None: return "null"
            if obj is True: return "true"
            if obj is False: return "false"
            if isinstance(obj, int): return str(obj)
            if isinstance(obj, float): return _encode_number(obj)
            if isinstance(obj, str):
                return json.dumps(obj, ensure_ascii=False, separators=(",", ":"))
            if isinstance(obj, list):
                return "[" + ",".join(_canon(v) for v in obj) + "]"
            if isinstance(obj, dict):
                items = sorted(obj.items(), key=lambda kv: kv[0])
                return "{" + ",".join(json.dumps(k, ensure_ascii=False, separators=(",", ":")) + ":" + _canon(v) for k,v in items) + "}"
            raise TypeError(f"Unsupported type: {type(obj)}")

        def canonicalize(data: Any) -> bytes:
            return _canon(data).encode("utf-8")
