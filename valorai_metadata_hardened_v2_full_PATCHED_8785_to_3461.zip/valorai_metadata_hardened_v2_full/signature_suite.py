"""
signature_suite.py — Ed25519 & secp256k1 signing/verification with detachable JWS/COSE helpers.
"""
from typing import Optional
import base64, json, hashlib

B64URL = lambda b: base64.urlsafe_b64encode(b).rstrip(b"=").decode("ascii")

def _sha256(data: bytes) -> bytes:
    return hashlib.sha256(data).digest()

def ed25519_sign(priv_pem: bytes, payload: bytes) -> bytes:
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        from cryptography.hazmat.primitives import serialization
        key = serialization.load_pem_private_key(priv_pem, password=None)
        if not isinstance(key, Ed25519PrivateKey):
            raise ValueError("PEM is not Ed25519 private key")
        return key.sign(payload)
    except Exception as e:
        try:
            import nacl.signing
            key = nacl.signing.SigningKey.from_seed(_sha256(priv_pem))
            signed = key.sign(payload)
            return bytes(signed.signature)
        except Exception as e2:
            raise RuntimeError("No Ed25519 backend available. Install 'cryptography' or 'pynacl'.") from e2

def ed25519_verify(pub_pem: bytes, payload: bytes, signature: bytes) -> bool:
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        from cryptography.hazmat.primitives import serialization
        key = serialization.load_pem_public_key(pub_pem)
        key.verify(signature, payload)
        return True
    except Exception:
        try:
            import nacl.signing
            verify_key = nacl.signing.VerifyKey(_sha256(pub_pem))
            verify_key.verify(payload, signature)
            return True
        except Exception:
            return False

def secp256k1_sign(priv_pem: bytes, payload: bytes) -> bytes:
    try:
        from cryptography.hazmat.primitives.asymmetric import ec
        from cryptography.hazmat.primitives import hashes, serialization
        key = serialization.load_pem_private_key(priv_pem, password=None)
        if not isinstance(key, ec.EllipticCurvePrivateKey) or key.curve.name != "secp256k1":
            raise ValueError("PEM is not secp256k1 private key")
        return key.sign(payload, ec.ECDSA(hashes.SHA256()))
    except Exception:
        try:
            import ecdsa
            sk = ecdsa.SigningKey.from_pem(priv_pem.decode("utf-8"))
            return sk.sign_deterministic(payload, hashfunc=hashlib.sha256, sigencode=ecdsa.util.sigencode_der)
        except Exception as e2:
            raise RuntimeError("No secp256k1 backend available. Install 'cryptography' or 'ecdsa'.") from e2

def secp256k1_verify(pub_pem: bytes, payload: bytes, signature: bytes) -> bool:
    try:
        from cryptography.hazmat.primitives.asymmetric import ec
        from cryptography.hazmat.primitives import serialization, hashes
        key = serialization.load_pem_public_key(pub_pem)
        key.verify(signature, payload, ec.ECDSA(hashes.SHA256()))
        return True
    except Exception:
        try:
            import ecdsa
            vk = ecdsa.VerifyingKey.from_pem(pub_pem.decode("utf-8"))
            return vk.verify(signature, payload, hashfunc=hashlib.sha256, sigdecode=ecdsa.util.sigdecode_der)
        except Exception:
            return False

def jws_detached(payload: bytes, alg: str, key_pem: bytes, kid: Optional[str] = None) -> str:
    header = {"alg": alg}
    if kid: header["kid"] = kid
    encoded_header = B64URL(json.dumps(header, separators=(",", ":"), sort_keys=True).encode("utf-8")).encode("ascii")
    encoded_payload = b""  # detached
    signing_input = encoded_header + b"." + encoded_payload
    if alg == "EdDSA":
        sig = ed25519_sign(key_pem, payload if payload else b"")
    elif alg == "ES256K":
        sig = secp256k1_sign(key_pem, payload if payload else b"")
    else:
        raise ValueError("Unsupported alg for this helper: use EdDSA or ES256K")
    encoded_sig = B64URL(sig).encode("ascii")
    return (encoded_header + b"." + encoded_payload + b"." + encoded_sig).decode("ascii")

def cose_sign1_detached(payload: bytes, alg: str, key_pem: bytes) -> bytes:
    try:
        from cose.messages import Sign1Message
        from cose.algorithms import EdDSA, Es256K
        from cose.headers import Algorithm
        if alg == "EdDSA":
            cose_msg = Sign1Message(phdr={Algorithm: EdDSA}, uhdr={}, payload=b"")
        elif alg == "ES256K":
            cose_msg = Sign1Message(phdr={Algorithm: Es256K}, uhdr={}, payload=b"")
        else:
            raise ValueError("Unsupported COSE alg")
        return cose_msg.encode(tag=True)
    except Exception as e:
        raise RuntimeError("COSE backend not available. Install 'cose'.") from e
